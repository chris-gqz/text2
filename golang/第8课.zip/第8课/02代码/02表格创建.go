package main

import (
	"fmt"
	"github/tealeg/xlsx"
)

type Cell struct {
	Name []string
}
type Row struct {
	Cell
}

type Sheet struct {
	Sname string
	Row
}

func CreateExcel(sheet Sheet) {
	//创建表格
	file := xlsx.NewFile()
	//设置页面名称
	s, err := file.AddSheet(sheet.Sname)
	if err != nil {
		fmt.Println(err)
		return
	}
	row := s.AddRow()
	row.SetHeightCM(1.5)
	for _, v := range sheet.Name {
		cell := row.AddCell()
		cell.Value = v
	}
	//添加数据


	//保存文件："D:/学员信息表.xlsx"
	err = file.Save("D:/学员信息表.xlsx")
	if err != nil {
		fmt.Println(err)
		return
	}

}

func main() {

	//表格页面
	sheet := Sheet{"Go语言开发", Row{Cell{[]string{"姓名", "性别", "年龄", "成绩", "住址"}}}}
	CreateExcel(sheet)
}

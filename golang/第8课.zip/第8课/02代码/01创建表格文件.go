package main

import (
	"fmt"
	"github/tealeg/xlsx"
)

func main() {
	//新建表格
	file := xlsx.NewFile()


	//创建页面
	file.AddSheet("test")


	//保存文件
	err := file.Save("D:/test.xlsx")

	if err != nil {
		fmt.Println("表格文件有误：", err)
		return
	}
}

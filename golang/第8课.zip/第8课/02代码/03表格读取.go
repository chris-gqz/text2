package main

import (
	"fmt"
	"github/tealeg/xlsx"
	"time"
)

type Person struct {
	Name       string //微信昵称
	Education  string //学历
	University string //高校
	Industry   string //行业
	Workyear   string //工作年限
	Position   string //职位
	Salary     string //薪资
	Language   string //编程语言
}

func GetExcel() {
	//学员信息结构体
	var per []Person
	file, err := xlsx.OpenFile("D:/Go语言工程师信息表.xlsx")
	if err != nil {
		fmt.Println(err)
		return
	}
	//页面
	for _, sheet := range file.Sheets {
		//行
		for _, row := range sheet.Rows {
			//临时数据
			var temp Person
			var str []string //interface{}
			//列
			for _, cell := range row.Cells {
				str = append(str, cell.String())
			}
			temp.Name = str[0]
			temp.Education = str[1]
			temp.University = str[2]
			temp.Industry = str[3]
			temp.Workyear = str[4]
			temp.Position = str[5]
			temp.Salary = str[6]
			temp.Language = str[7]
			//将数据存放在切片中
			per = append(per, temp)
		}

	}

	//打印数据
	for i, v := range per {
		fmt.Println(i, v)
	}
}
func main() {
	GetExcel()

	time.Sleep(time.Second * 100)
}

package main

import "fmt"

func main() {
	sn1 := struct {
		name string
		age  int
	}{name: "qq", age: 11}

	sn2 := struct {
		age  int
		name string
	}{age: 11, name: "qq"}

	//两个结构体比较 比较的是内容 也和结构体成员的顺序有关
	if sn1 != sn2 {
		fmt.Println("sn1 == sn2")
	} else {
		fmt.Println("sn1 != sn2")
	}
}

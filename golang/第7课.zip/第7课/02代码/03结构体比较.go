package main

import "fmt"

func main() {
	sn1 := struct {
		age  int
		m   map[string]string
	}{age: 11,m: map[string]string{"a": "1"}}

	sn2 := struct {
		age  int
		m   map[string]string
	}{age: 11, m: map[string]string{"a": "1"}}
	//结构体比较和成员类型有关
	//if sn1 == sn2 {
	//	fmt.Println("sn1 == sn2")
	//}
	if sn1.m["a"] == sn2.m["a"] && sn1.age==sn2.age{
		fmt.Println("值相同")
	}
}
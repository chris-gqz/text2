package main

import (
	"encoding/json"
	"fmt"
)

type Class struct {
	//结构体转成json 成员必须首字母大写
	Subject  string
	Students []string
	Pirce    float64
}

func main0401() {
	cl := Class{"go语言开发", []string{"王宏达", "老四", "汉斯", "安艺君"}, 8980.88}
	//slice, err := json.Marshal(cl)
	//结果：{"Subject":"go语言开发","Students":["王宏达","老四","汉斯","安艺君"],"Pirce":8980.88}

	slice, err := json.MarshalIndent(cl, "", "    ")
	/*
		{
		    "Subject": "go语言开发",
		    "Students": [
		        "王宏达",
		        "老四",
		        "汉斯",
		        "安艺君"
		    ],
		    "Pirce": 8980.88
		}
	*/
	if err != nil {
		fmt.Println("json err:", err)
		return
	}
	fmt.Println(string(slice))
}

func main() {
	//slice := []byte(`{"Subject":"go语言开发","Students":["王宏达","老四","汉斯","安艺君"],"Pirce":8980.88}`)
	slice:=[]byte(`		{
		    "Subject": "go语言开发",
		    "Students": [
		        "王宏达",
		        "老四",
		        "汉斯",
		        "安艺君"
		    ],
		    "Pirce": 8980.88
		}`)
	var cl Class
	err := json.Unmarshal(slice, &cl)
	if err != nil {
		fmt.Println("json err:", err)
		return
	}
	fmt.Println(cl)
	fmt.Println(cl.Subject)
	fmt.Println(cl.Students)
	fmt.Println(cl.Pirce)

}

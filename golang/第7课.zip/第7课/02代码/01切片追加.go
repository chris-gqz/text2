package main

import "fmt"

func main0101() {
	//new make
	list := new([]int)
	//list  指针类型  *[]int
	*list = append(*list, 1)
	fmt.Println(list)
}

func main0102() {
	s1 := []int{1, 2, 3}
	s2 := []int{4, 5}
	//...称为不定参 实现原理等同于切片
	s1 = append(s1, s2...)

	fmt.Println(s1)
}

func test(a ...int){
	fmt.Println(a)
}
func sum(arr ...int) {

	//fmt.Println(arr)
	fmt.Printf("%T\n", arr)
	//fmt.Println(len(arr))
	//fmt.Println(cap(arr))
	//
	//for i, v := range arr {
	//	fmt.Println(i, v)
	//}
	//如果操作不定参 必须要添加...
	test(arr...)
}
func main() {
	sum(1, 2, 3, 4, 5)
}



package main

import (
	"encoding/json"
	"fmt"
)

func main0501() {
	m := make(map[string]interface{})
	//map的可以转成json不区分大小写
	m["subject"] = "go语言开发"
	m["students"] = []string{"王宏达", "老四", "汉斯", "安艺君", "法师"}
	m["price"] = 8980.88

	//slice, err := json.Marshal(m)
	//结果：{"price":8980.88,"students":["王宏达","老四","汉斯","安艺君","法师"],"subject":"go语言开发"}

	slice, err := json.MarshalIndent(m, "", "    ")
	/*
		{
		    "price": 8980.88,
		    "students": [
		        "王宏达",
		        "老四",
		        "汉斯",
		        "安艺君",
		        "法师"
		    ],
		    "subject": "go语言开发"
		}
	*/
	if err != nil {
		fmt.Println("json err:", err)
		return
	}
	fmt.Println(string(slice))
}

func main() {
	slice := []byte(`{"price":8980.88,"students":["王宏达","老四","汉斯","安艺君","法师"],"subject":"go语言开发"}`)

	//创建 map[string]interface{}
	//json的key对应map的string value对应interface{}
	m := make(map[string]interface{})
	//var temp interface{}
	//err := json.Unmarshal(slice, &temp)
	err := json.Unmarshal(slice, &m)
	if err != nil {
		fmt.Println("json err:", err)
		return
	}
	//fmt.Println(m)
	//fmt.Printf("%T\n", temp)
	//map的value为interface 需要进行类型断言 获取数据内容
	for k, v := range m {
		switch tv := v.(type) {
		//case interface{}:
		//	fmt.Println("interface数据类型：",k, tv)
		case string:
			fmt.Println("string类型数据：", k, tv)
		case float64:
			fmt.Println("float64数据类型：", k, tv)
		//case []string:				//err
		//	fmt.Println("[]string类型数据", k, tv)
		case []interface{}:
			fmt.Println("[]interface数据类型", k, tv)
			//fmt.Printf("%T\n", tv)
			for i, val := range tv {
				fmt.Println(i, val)
			}
		default:
			fmt.Println("未匹配数据：", k, v)
		}
	}
}

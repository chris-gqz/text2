package main

import (
	"fmt"
	"os"
)

func main() {
	f, err := os.Create("D:/test.txt")
	if err != nil {
		fmt.Println("文件创建失败")
		return
	}
	//关闭文件
	defer f.Close()
	fmt.Println("文件操作成功")
}

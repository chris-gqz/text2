package main

import (
	"fmt"
	"os"
	"os/exec"
)

func main() {
	f, err := os.Open("D:/dict.txt")
	if err != nil {
		fmt.Println("open file error")
		return
	}
	defer f.Close()

	//等同于system
	cmd := exec.Command("mspaint")
	cmd.Start()

	//buf := make([]byte, 1024)
	////读取整个文件内容
	//for {
	//	n, err := f.Read(buf)
	//	//err错误信息：EOF  end of file
	//	if err == io.EOF {
	//		break
	//	}
	//	fmt.Println(string(buf[:n]))
	//
	//}
}

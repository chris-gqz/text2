package main

import (
	"fmt"
	"os"
)

func main() {
	//os.Open 只读方式打开文件
	f, err := os.Open("D:/test.txt")
	if err != nil {
		fmt.Println("文件打开失败")
		return
	}
	defer f.Close()

	buf := make([]byte, 1024)

	//读取文件
	//n, _ := f.Read(buf)
	//指定位置读取
	n, _ := f.ReadAt(buf, 6)

	fmt.Println(string(buf[:n]))
}
func main0702() {
	f, err := os.OpenFile("D:/test.txt", os.O_RDWR|os.O_CREATE, 660)
	if err != nil {
		fmt.Println("文件打开失败")
		return
	}
	defer f.Close()
	//文件字符串写入
	//f.WriteString("你瞅啥")
	//指定位置写入
	//f.WriteAt([]byte("小帅哥来玩啊"), 10)
	//字符切片写入
	//windows文本文件换行以\r\n 为换行
	//linux文本文件换行以\n 为换行
	f.Write([]byte("性感法师在线讲课\r\n"))
	f.Write([]byte("风骚学生在线聆听"))
}

package main

import (
	"fmt"
	"unsafe"
)

func main() {

	//map的key的类型 必须支持== != 运算符的操作 不可以是函数 map 切片
	//map是无序的  在做查找时速度快
	//var m map[int]string //nil
	m := make(map[int]string)

	m[1001] = "法师"
	m[1008] = "王宏达"
	//删除元素
	//delete(m, 1001)

	fmt.Println(m)

	//计算数据类型在内存中占的字节大小
	fmt.Println(unsafe.Sizeof(m))
	fmt.Printf("%p\n", m)
}

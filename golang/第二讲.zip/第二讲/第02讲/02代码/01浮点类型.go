package main

import "fmt"

func main() {
	//建议使用float64代替float32
	//a := 3.14 //float64
	var a float64 = 3.14
	var b float32 = 3.14

	//小数点后保留20位  默认保留六位 会对第7位进行四舍五入
	fmt.Printf("%.20f\n",a)
	fmt.Printf("%.20f\n",b)
}

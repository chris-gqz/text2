package main

import (
	"fmt"
	"unsafe"
)

func BubbleSort01(arr [10]int) {
	//len(数组名)  计算数组的元素个数
	for i := 0; i < len(arr)-1; i++ {
		for j := 0; j < len(arr)-1-i; j++ {
			//比较两个相邻元素  满足条件交换数据
			if arr[j] > arr[j+1] {
				//多重赋值
				arr[j], arr[j+1] = arr[j+1], arr[j]
			}
		}
	}
	fmt.Println(arr)
}

func main05() {

	//var 数组名 [元素个数]数据类型
	var arr [10]int = [10]int{9, 1, 5, 6, 10, 8, 3, 7, 2, 4}

	//使用数组名+下标
	//arr[0] = 123
	//数组作为函数参数为值传递 形参不可以修改实参的值
	BubbleSort01(arr)

}
func main06() {

	//var 切片名 []数据类型
	//var slice []int //nil

	//make([]数据类型，长度，容量)
	slice := make([]int, 10, 30)
	fmt.Println(slice)
	//len(切片) //计算切片的长度
	//cap(切片) //计算切片的容量

	fmt.Printf("%p\n", slice)
	fmt.Println(unsafe.Sizeof(slice))
}

func BubbleSort(slice []int) {
	for i := 0; i < len(slice)-1; i++ {
		for j := 0; j < len(slice)-1-i; j++ {
			if slice[j] > slice[j+1] {
				slice[j], slice[j+1] = slice[j+1], slice[j]
			}
		}
	}
}

//解决方案：使用返回值  使用指针
func testappend(slice []int) {
	fmt.Printf("T : %p\n", slice)
	slice = append(slice, 1, 1, 1, 1, 1)
	//内存地址发生变化
	fmt.Printf("T : %p\n", slice)
	fmt.Println(slice)

}
func main07() {
	slice := []int{9, 1, 5, 6, 10, 8, 3, 7, 2, 4}
	fmt.Printf("M : %p\n", slice)

	//切片包含指针  指向数据的位置
	//BubbleSort(slice)
	testappend(slice)
	fmt.Println(slice)

}

func main() {
	//切片截取和拷贝
	//切片截取是在源切片基础上进行操作 修改一个会影响另外一个
	//slice := []int{9, 1, 5, 6, 10, 8, 3, 7, 2, 4}

	//切片:=slice[起始位置:结束位置：容量]
	//切片的截取  左闭右开 包含左面 不包含右面
	//s := slice[2:6]
	////fmt.Println(s)
	////修改切片s
	//s[2] = 123
	//fmt.Println(s)
	//fmt.Println(slice)
	//
	//fmt.Printf("%p\n",slice)
	//fmt.Printf("%p\n",s)

	slice := []int{9, 1, 5, 6, 10, 8, 3, 7, 2, 4}
	//切片的拷贝
	var s []int = make([]int, 10, 20)
	copy(s, slice)

	s[2] = 666
	fmt.Println(s)
	fmt.Println(slice)

	fmt.Printf("%p\n", slice)
	fmt.Printf("%p\n", s)

}

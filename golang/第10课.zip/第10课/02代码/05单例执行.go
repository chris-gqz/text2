package main

import (
	"fmt"
	"sync"
)

func main() {
	var once sync.Once
	var wg sync.WaitGroup
	f := func() {
		fmt.Println("性感法师，在线讲课")
	}
	wg.Add(1000)
	for i := 0; i < 1000; i++ {
		go func() {
			defer wg.Done()
			//设计模式：单例
			once.Do(f)
		}()
	}
	wg.Wait()

}

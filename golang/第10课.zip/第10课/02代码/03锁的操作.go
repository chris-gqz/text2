package main

import (
	"fmt"
	"sync"
)

var n int
var mu sync.Mutex
var wg sync.WaitGroup

func test() {
	mu.Lock() //加锁
	defer func() {
		mu.Unlock() //解锁
		wg.Done()
	}()
	n++
}
func main() {
	wg.Add(10000)
	for i := 0; i < 10000; i++ {
		go test()
	}
	wg.Wait()
	fmt.Println(n)
	//sync.WaitGroup{}
}

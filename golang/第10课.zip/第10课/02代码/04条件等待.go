package main

import (
	"fmt"
	"sync"
	"time"
)

func main() {

	//等待组
	var wg sync.WaitGroup
	//创建条件等待
	cond := sync.NewCond(new(sync.Mutex))
	for i := 0; i < 3; i++ {
		go func(i int) {
			fmt.Println("启动协程:", i)
			wg.Add(1)
			defer wg.Done()
			cond.L.Lock()
			fmt.Println("协程加锁:", i)
			cond.Wait()
			fmt.Println("协程解锁:", i)
			cond.L.Unlock()
		}(i)
	}


	time.Sleep(time.Second*2)
	fmt.Println("---------------------")
	//发送信号
	cond.Signal()

	time.Sleep(time.Second)
	//发送信号
	cond.Signal()

	time.Sleep(time.Second)
	//发送信号
	cond.Signal()

	wg.Wait()
}

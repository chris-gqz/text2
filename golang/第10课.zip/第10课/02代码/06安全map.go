package main

import (
	"fmt"
	"sync"
)

func main() {
	var m sync.Map
	//赋值
	m.Store("法师", 95)
	m.Store("宏达", 100)
	m.Store("老翰", 200)
	//取值
	val, ok := m.Load("宏达")
	if ok {
		fmt.Println(val)
	} else {
		fmt.Println("数据不存在")
	}
	//删除
	m.Delete("法师")

	//遍历  无序
	m.Range(func(key, value interface{}) bool {
		//获取数据
		fmt.Println(key, value)
		return true
	})
}

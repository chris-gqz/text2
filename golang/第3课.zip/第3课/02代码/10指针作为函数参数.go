package main

import "fmt"

func swap(a *int, b *int) {
	//交换a和b的值
	a, b = b, a
}
func test11(array ...int){

}
func main() {
	a := 10
	b := 20
	swap(&a, &b)

	fmt.Println(a, b)
}

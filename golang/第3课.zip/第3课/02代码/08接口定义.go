package main

import "fmt"

type Humaner interface {
	//方法的声明
	SayHello()
}

type Student3 struct {
	name  string
	age   int
	score int
}

func (s *Student3) SayHello() {
	fmt.Println("大家好，我叫：", s.name)
}

type People3 struct {
	id string
	lv int
}

func (p *People3) SayHello() {
	fmt.Println("我是：", p.id)
}
func (p *People3) GetName() {
	fmt.Println("我是：", p.id)
}

//函数 - 多态  将接口作为函数参数
func SayHello(h Humaner) {
	h.SayHello()
}

func main() {
	stu := Student3{"汉斯", 18, 101}
	peo := People3{"郑阳", 100}
	//stu.SayHello()

	////定义接口类型变量
	//var h Humaner
	////必须将对象的地址赋值给接口类型变量
	//h = &stu
	//h.SayHello()
	//
	//h = &peo
	//h.SayHello()

	SayHello(&stu)
	SayHello(&peo)
}

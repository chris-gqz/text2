package main

import (
	"fmt"
	"unsafe"
)

type Student struct {
	//结构体成员存储在内存中 会按照数据类型中最大的数据的整数倍数进行存储
	name string //16
	sex  byte   //1  7
	age  int    //8
	addr string //16
	aa   int32
	bb   int32
}

func main0301() {
	var s Student
	fmt.Printf("%p\n", &s)
	fmt.Printf("%p\n", &s.name)
	fmt.Printf("%p\n", &s.sex)
	fmt.Printf("%p\n", &s.age)
	fmt.Printf("%p\n", &s.addr)

	//计算结构体在内存中占的字节大小
	fmt.Println(unsafe.Sizeof(s))
}

type NULL struct {
}

func main() {
	//定义空结构体
	//在特殊的channel中使用 不可以写入数据 只有close关系才能进行输出操作
	//a:= struct {}{}
	a1 := NULL{}

	a2:= struct {}{}
	a3:= struct {}{}
	//fmt.Println(unsafe.Sizeof(a))


	fmt.Printf("%p\n", &a1)
	fmt.Printf("%p\n", &a2)
	fmt.Printf("%p\n", &a3)
}

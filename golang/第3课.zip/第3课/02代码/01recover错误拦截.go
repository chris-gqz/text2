package main

import "fmt"

/*
1、编辑时异常
2、编译时异常
3、运行时异常
*/
func Demo(i int) {
	//定义数组
	var arr [10]int
	//设置错误拦截 defer + 匿名函数 +recover
	defer func() {
		err := recover()
		if err != nil {
			fmt.Println(err)
		}
	}()
	//数组下标越界
	arr[i] = 123

	fmt.Println(1)
	fmt.Println(2)
	fmt.Println(3)
}
func main() {
	Demo(10)

	fmt.Println("程序继续执行...")
}

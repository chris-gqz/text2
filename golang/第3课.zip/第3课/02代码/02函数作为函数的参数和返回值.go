package main

import "fmt"

func add(a int, b int) int {
	return a + b
}

//将函数作为函数参数（函数回调）
func operator(f func(int, int) int) {
	value := f(10, 20)
	fmt.Println(value)
}
func main01() {
	//打印函数的内存地址
	//fmt.Println(add)
	operator(add)
}

type FUNC func() int

//函数作为函数的返回值（闭包）
func Demo1() FUNC {
	i := 0
	return func()int {
		i += 1
		fmt.Printf("%p\n", &i)

		return i
	}
}
func main() {
	f := Demo1()
	fmt.Println(f()) //1
	fmt.Println(f()) //2
	fmt.Println(f()) //3
	//fmt.Printf("%T\n", f)

	f1 := Demo1()
	fmt.Println(f1()) //1
	f = nil
	f1 = nil
}

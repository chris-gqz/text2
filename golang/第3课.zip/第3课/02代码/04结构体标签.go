package main

import (
	"fmt"
	"reflect"
)

type People struct {
	Name string `json:"name"`
	Age  int    `json:"age"`
}

func main() {
	//通过反射回去tag设置
	to := reflect.TypeOf(People{})
	//fmt.Printf("%T\n", to)
	for i := 0; i < to.NumField(); i++ {
		field := to.Field(i)
		tag := field.Tag.Get("json")
		fmt.Println(tag)
	}
}

package main

import "fmt"

type Student1 struct {
	Name  string
	Age   int
	Score int
}

//方法定义
//func (方法接收者)方法名(参数列表)(返回值列表){
//	代码体
//	返回值
//}
//值对象接收者
//无须修改对象
//引用类型 字符串 函数
//调用时会按照其一个副本来执行调用
func (s Student1) SayHello1() {
	//fmt.Println(s.Name, ": hello")
	s.Name = "达达"
}

//指针对象接收者
//需要修改数据
//大对象地址
//按照实际的值来调用
func (s *Student1) SayHello2() {
	//fmt.Println(s.Name, ": hello")
	s.Name = "达达"
}
func main() {
	stu := Student1{"王宏达", 18, 100}
	//对象。方法
	stu.SayHello2()
	fmt.Println(stu)
}

package main

import "fmt"

type people struct {
	Name string
	Age  int
}

//结构体嵌套结构体
type student struct {
	//将一个结构体作为另外一个结构体成员
	people
	Name  string
	Score int
}

func main() {
	s := student{people{"王宏达", 18,}, "达达",100}
	//s.Name = "老四"
	fmt.Println(s)
	fmt.Println(s.Name)
	fmt.Println(s.people.Name)
}

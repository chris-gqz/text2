package main

import (
	"fmt"
	"strings"
)

func main() {
	//s := strings.TrimRight("abcdefedmcba", "fedabc")
	//fmt.Printf("%q\n", s)
	//按照顺序删除
	s:=strings.TrimSuffix("abcdefedcbaabcdef","abcdef")
	fmt.Printf("%q\n",s)
}
package main

import (
	"fmt"
	"time"
)

func main() {
	t := time.NewTicker(time.Second*5)
	defer t.Stop()

	for range t.C {
		fmt.Println(1)
	}

}
package main

import "fmt"

func main() {
	a := 2 ^ 15 //13
	b := 4 ^ 15 //11
	fmt.Println(a, b)
	if a > b {
		println("a")
	} else {
		println("b")
	}

}

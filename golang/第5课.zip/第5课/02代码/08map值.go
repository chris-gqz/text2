package main

import (
	"fmt"
)

func main0801() {
	m := make(map[string]int)
	m["foo"]++
	//为map添加元素
	//m["foo"] = 0
	//m["foo"] += 1
	fmt.Println(m["foo"])
}

//"shfsdhfklsdhgfjsdhkkfjsdfhysjdkfgsdhyfjhdsjhbfhsdj"统计每个字符出现的次数

func main0802() {
	str := "shfsdhfklsdhgfjsdhkkfjsdfhysjdkfgsdhyfjhdsjhbfhsdj"

	fmt.Printf("%T\n", str)
	//slice:=[]byte(str)
	m := make(map[rune]int)

	for _, v := range str {
		m[v]++
	}

	for k, v := range m {

		fmt.Printf("%c:%d\n", k, v)
	}
}

type Student struct {
	name string
	age  int
}

func main0803() {
	m := make(map[int]Student)
	m[1001] = Student{"王宏达", 18}
	//不允许通过map的key找到value内部地址操作
	//m[1001].name
	//m[1001].age=18
	m[1001] = Student{"老四", 20}
	//fmt.Println(m[1001].name)
	fmt.Println(m)
}

type null NULL
type NULL struct {
}

func main(){
	var n null

	if n == struct {}{}{
		fmt.Println("空结构体")
	}
}
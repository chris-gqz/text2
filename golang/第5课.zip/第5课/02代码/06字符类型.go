package main

import (
	"fmt"
	"strconv"
)

func main0601() {
	//rune数据类型  支持中文编码集
	r := []rune("你好")

	for _, v := range r {
		//%c 打印一个字符
		//%q 打印带引号字符
		fmt.Printf("%q", v)

	}
	//fmt.Println(r)
}

func main0602() {
	//string类型 可以转成[]byte []rune
	b := []byte("Hello")
	r := []rune("Seattle")
	//i := []int("Gophers")


	//将字符串转成整型
	i,err:=strconv.Atoi("hello")
	if err!=nil{
		fmt.Println("转换错误")
	}else{
		fmt.Println(i)
	}
	fmt.Println(b, r, i)
}


func main() {
	//可以支持图片
	fmt.Println("Seattle, WA ☔")
}
package main

import "fmt"

type P  *int
type Q  *int

func main0701() {
	var p P = new(int)
	//如果操作为引用类型 别名和本类型可以赋值
	var m *int = p
	fmt.Println(m)

	//fmt.Printf("%T\n",p)
	//fmt.Printf("%T\n",m)
	var q Q = new(int)
	//fmt.Println(q)
	fmt.Printf("%T\n", p)
	fmt.Printf("%T\n", q)
}

func main0702() {
	//p 和 q 执行同一个内存地址空间
	var p P = new(int)
	*p += 8
	//var x *int = p
	var q Q = p
	*q++
	fmt.Println(*p, *q)
	fmt.Println(p)
	fmt.Println(q)
	//fmt.Println(x)

}

type T []int

//一般在开发中 为函数起别名  函数可以作为函数的参数

func main0703() {
	var x []int
	var y T

	//x 和 y  可以直接赋值吗？
	y = x
	fmt.Println(y)

}

func F(t T) {}

func main0704() {
	var x []int
	var y T
	y = x
	F(x)
	_ = y
}

//为结构体切别名
type stu student

type student struct {
	name string
	age  int
}

func main0705() {
	var s student = student{"王宏达", 18}
	var s1 stu
	//结构体本身不是引用类型
	//s1 = s
	fmt.Println(s)
	fmt.Println(s1)
}

type m1 map[int]string

type m2 map[int]string

func main() {

	var v1 m1 = map[int]string{1001: "王宏达"}
	var v map[int]string = v1

	var v2 m2=v

	fmt.Println(v2)
}

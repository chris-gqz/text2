package main

import "fmt"

func main() {
	v := []int{1, 2, 3}


	//len(切片)  计算切片的有效数据大小
	//cap(切片)  计算切片的有效容量大小
	//不会出现死循环  range 会对数据进行拷贝
	for i := range v {
		//如果超过容量 变更内存地址  如果不超过容量 不变更内存地址
		v = append(v, i)
		v = append(v, i)
		//fmt.Printf("%p\n",&v)//&切片名  切片本身存储位置
		fmt.Printf("%p\n",v)	//切片名  表示array地址
	}
	fmt.Println(v)
}

package main

/*
#include "stdio.h"
void Print()
{
	printf("hello world\n");
}
 */
import "C"
import (
	"fmt"
)

func main(){
	fmt.Println("hello world");
	fmt.Println("性感法师 在线教学")

	//不建议在定义变量或函数时使用中文
	var 变量  int =123
	和:=变量+123
	fmt.Println(变量)
	fmt.Println(和)
	//调用C语言函数
	C.Print()
}

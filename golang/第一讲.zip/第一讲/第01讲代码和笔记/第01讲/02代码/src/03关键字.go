package main

//可以为包起别名
//如果使用包的初始化或接口实现 并没有明显调用  需要使用_来区分
import (
	"fmt"
	//"demo"
	//fdemo "fmt/demo"

	"demo"
	"time"
)

func main01() {
	//定义变量
	//var 变量名 数据类型 = 值
	//var a int = 10
	//var b = 20
	////自动推导类型
	//c := 30
	//
	//多重赋值
	a, b, c := 1, true, "你瞅啥"

	a1 := 123
	a2 := 666
	//使用多重赋值来完成变量的交换
	a1, a2 = a2, a1

	fmt.Println(a)
	fmt.Println(b)
	fmt.Println(c)

	fmt.Println(a1, a2)

	//%T 表示打印数据类型
	//fmt.Printf("%T\n",a)
	//fmt.Printf("%T\n",b)
	//fmt.Printf("%T\n",c)
}

func main02() {
	//a:=123
	//一般建议常量名大写
	//const PI = 3.1415926
	//const MAX = 100

	//在Go语言中 常量不允许寻址
	//& 取地址运算符
	//fmt.Println(&a)
	//fmt.Println(&PI)

	//iota常量集  枚举enum
	//const (
	//	a       = iota
	//	b       = iota
	//	c, d, e = iota, iota, iota
	//)
	const (
		a = 123
		b = true
		c = "瞅你咋地"
		d = 1.2345
	)
	fmt.Println(a, b, c, d)
}

//函数的格式
/*
func 函数名(函数参数列表)(返回值列表){
	//代码体
	//返回值 return
}
 */
func main03() {
	demo.Test()
	//匿名函数  必须在函数内部定义
	//func(参数列表)(返回值列表){
	//
	//}()

	//函数类型
	var f func(int, int)
	//函数类型变量
	f = func(a int, b int) {
		fmt.Println(a + b)
	}

	//通过函数类型调用函数
	f(10, 20)
	fmt.Printf("%T\n", f)

}

//为函数定义类型
type FUNCTYPE = func(int, bool, string)

func demo1(a int, b bool, c string) {
	fmt.Println("再瞅一个试试 瓜娃子")
}

//函数回调
func demo2(f FUNCTYPE) {
	f(1, false, "")
}
func main04() {
	//type
	//1、为已存在的数据类型起别名
	//2、为函数定义类型
	type i8 int8 //如果没有等号  不允许计算
	//type i8 = int8 //如果有等号  允许计算

	//var a i8 = 123
	//var b int8 = 1
	//fmt.Println(a + b)//err

	//byte字符类型
	//var ch byte = 'a'
	//fmt.Println(ch)

	var f FUNCTYPE
	//将函数赋值给函数类型的的变量
	f = demo1
	//f(1, false, "")
	demo2(f)
}
func main05() {
	//空接口类型 可以接收任意类型数据
	var a interface{}
	a = 123
	//var b interface{} = 456
	//a = 1.234
	//a = "hello"
	//fmt.Println(a + b)
	//通过反射获取空接口数据对应的类型
	//t := reflect.TypeOf(a)
	//通过反射获取空接口数据对应的值
	//a1 := reflect.ValueOf(a)

	//类型断言
	//接口类型变量.(数据类型)
	a1, ok := a.(int)
	if ok {
		//操作a1
	} else {
		//抛出异常
	}
	fmt.Println(a1)
	fmt.Println(ok)
	fmt.Printf("%T\n", a1)
	fmt.Printf("%T\n", ok)
}

//结构体定义
/*
type 结构体名称 struct{
	//结构体成员列表
	变量名 数据类型
}
 */

func main06() {
	//通过结构体实现链表
	//结构体初始化
	var stu demo.Student

	//结构体变量.成员
	stu.Id = 1001
	stu.Sex = "女"
	stu.Addr = "黑龙江哈尔滨"
	stu.Name = "王宏达"
	stu.Socre = 100
	fmt.Println(stu)
}

func main08() {
	//创建一个空的 map
	//var m1 map[int]string //默认值为nil
	//map中的key的类型不能是 函数 字典 切片
	//map中的数据是无序的
	m := make(map[int]string)
	m[1001] = "王宏达"
	m[1022] = "老四"
	m[1088] = "曙光"
	m[1101] = "汉斯"
	fmt.Println(m)

	//遍历集合中的数据
	for k, v := range m {
		fmt.Println(k, v)
	}

	//fmt.Printf("%p\n", m1)
	//fmt.Printf("%p\n", m2)
}

func main09() {
	go func() {
		fmt.Println("hello world")
	}()
	time.Sleep(time.Second * 10)
}

/*
if 表达式{
代码体1
}else{
代码体2
}

 */
func main10() {
	//1、switch 中case的值 不允许是浮点型  （因为浮点型是相对精准）
	//2、如果多个值执行相同内容 可以使用逗号分隔

	//计算一年每个月份的天数
	var m int
	fmt.Scan(&m)
	switch m {
	case 1, 3, 5, 7, 8, 10, 12:
		fmt.Println(31) //go语言中不需要在switch中使用break
		fallthrough     //让当前case向下执行
	case 4, 6, 9, 11:
		fmt.Println(30)
	case 2:
		fmt.Println("28 or 29")
	}

}

func main11() {
	//for i := 0; i < 10; i++ {
	//	fmt.Println(i)
	//  break//跳出循环
	//  continue //结束本次循环继续下次循环
	//}
	//for k,v:=range m{
	//
	//}

	fmt.Println(1)
	//不建议使用goto
FLAG:

	fmt.Println(2)
	fmt.Println(3)
	goto FLAG
	fmt.Println(4)
}
func main() {
	defer fmt.Println(1)
	defer fmt.Println(2)
	 fmt.Println(3)
	defer fmt.Println(4)
}
//命名规则
/*
1、允许使用字母 数字 下划线
2、区分大小写
3、不允许使用数字开头
4、不允许使用系统关键字
5、见名知义
 */
//面向对象
//通过匿名字段实现继承
//通过接口来实现多态
//通过方法实现封装
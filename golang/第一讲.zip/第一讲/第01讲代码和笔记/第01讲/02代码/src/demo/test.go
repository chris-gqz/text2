package demo

import "fmt"
type Student struct {
	Id    int
	Name  string
	Sex   string
	Socre int
	Addr  string
}
func Test() {
	fmt.Println("hello world")
	fmt.Println(a)
}

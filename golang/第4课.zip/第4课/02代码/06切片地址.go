package main

import "fmt"

func main() {
	slice := make([]int, 1,1)
	fmt.Printf("%p\n", slice)

	slice = append(slice, 1)

	fmt.Printf("%p\n", slice)


}

package main

import (
	"fmt"
	"time"
)

func main01() {
	go func() {
		fmt.Println("hello world")
	}()

	time.Sleep(time.Second * 5)
}
func main02() {
	//chan定义方式
	//var 变量 chan = make(chan 数据类型)
	//单向chan定义方式 函数传递的安全考虑
	//接收
	//ch:=make(chan<- 数据类型)
	//发送
	//ch:=make(<-chan 数据类型)
	//指定收发的大小
	//ch:=make(chan 数据类型 大小)


	//有缓存和无缓冲的区别
	//无缓冲 要求发送和接收 必须同时准备好，才能完成发送和接收 属于同步操作 会发生阻塞等待
	// 可以接收N个值 不要求同时指向 属于异步操作

	ch := make(chan int )
	go func() {
		value := <-ch
		fmt.Println(value)
	}()
	ch <- 123
	time.Sleep(time.Second)

	//close 通道不使用时可以调用进行关闭
}
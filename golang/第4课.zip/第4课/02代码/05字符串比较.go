package main

import "fmt"

func main() {
	//str1 := "hello"
	//str2 := "hello"
	//str1 += "world"
	//
	//if str1 == str2 {
	//	fmt.Println("相同")
	//}
	//fmt.Printf("%p\n", &str1)
	//fmt.Printf("%p\n", &str2)

	//字符串在操作时 不允许修改字符
	str := "hello"
	//fmt.Println(str[2])
	//str[2]='m'

	//字符串类型转换   内存拷贝
	slice := []byte(str)
	slice[2] = 'm'
	fmt.Println(slice)
	//slice:=[]byte{'h','e','l','l','o'}
	//
	//str:=string(slice)

}

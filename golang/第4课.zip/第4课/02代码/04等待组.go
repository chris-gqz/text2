package main

import (
	"fmt"
	"sync"
)

func main05() {
	//add done wait
	var m sync.Mutex
	c := 0
	waitg := sync.WaitGroup{}
	for i := 0; i < 100; i++ {
		waitg.Add(1)
		go func() {
			m.Lock()
			defer m.Unlock()
			defer waitg.Done()
			//fmt.Println(c)
			c++

		}()
	}
	waitg.Wait()
	fmt.Println(c)
}

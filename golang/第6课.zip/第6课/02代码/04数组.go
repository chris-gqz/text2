package main

import "fmt"

type Hash [32]byte

func MustNotBeZero(h Hash) {
	//需要使用系统提供类型 不允许使用自定义类型
	if h == [32]byte{} {
		fmt.Println(1)
	}
}

func main() {
	MustNotBeZero(Hash{})
}
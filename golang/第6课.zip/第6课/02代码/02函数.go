package main

import "fmt"

var x int

func init() {
	//x++
	//init()//err
	return
}

func main() {
	//无法在主函数中调用init函数
	//一个init函数只能执行一次
	//init()
	fmt.Println(x)
}
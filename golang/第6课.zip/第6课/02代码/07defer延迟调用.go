package main

import "fmt"

func main0701()  {
	defer func() { fmt.Println("1") }()
	defer func() { fmt.Println("2") }()
	defer func() { fmt.Println("3") }()

	panic("触发异常")
}



func calc(index string, a, b int) int {
	ret := a + b
	fmt.Println(index, a, b, ret)
	return ret
}

func main() {
	a := 1
	b := 2
	defer calc("1", a, calc("3", a, b))
	a = 0
	defer calc("2", a, calc("4", a, b))
	b = 1
}
package main

import (
	"fmt"
	"runtime"
	"sync"
	"time"
)

func main0501() {
	go func() {
		defer func() {
			err := recover()
			if err != nil {
				fmt.Println(err)
			}
		}()
		panic("Boom")
	}()
	for i := 0; i < 10000; i++ {
		fmt.Print(".")
	}
	fmt.Println("Done")
}


func A() int {
	fmt.Println("调用A函数")
	time.Sleep(100 * time.Millisecond)
	return 1
}

func B() int {
	fmt.Println("调用B函数")
	time.Sleep(1000 * time.Millisecond)
	return 2
}

func main0502() {
	ch := make(chan int)
	go func() {
		select {
		case ch <- A():
		case ch <- B():
		default:
			ch <- 3
		}
	}()
	fmt.Println(<-ch)
}


func main()  {
	runtime.GOMAXPROCS(0)
	wg := sync.WaitGroup{}
	wg.Add(10)
	for i := 0; i < 10; i++ {
		go func(i int) {
			fmt.Println(i)
			wg.Done()
		}(i)
	}
	//time.Sleep(time.Second)
	wg.Wait()
}

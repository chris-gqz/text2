package main

import "fmt"

//package ಠ_ಠ//ok
//package 100//err
//package ಠ~ಠ//err
//package 你好//ok


//func A(string string) string {
//	return string + string
//}

//func B(len int) int {
//	return len+len
//}

//func C(val, default string) string {
//	if val == "" {
//		return default
//}
//return val
//}

func 测试(){
	fmt.Println("调用测试函数")
}
func main0601() {
	var 变量 int = 10
	fmt.Println(变量)
	测试()

	r:='ಠ'
	fmt.Println(r)
}

func main() {
	i := GetValue()
	//类型断言  基于接口类型
	//接口变量.(type)  结果为数据类型
	switch i.(type) {
	case int:
		println("int")
	case string:
		println("string")
	case interface{}:
		println("interface")
	default:
		println("unknown")
	}
}
func GetValue() interface{} {
	return 1
}
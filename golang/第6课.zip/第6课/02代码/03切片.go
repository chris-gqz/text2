package main

import (
	"fmt"
)

func f(a int, b uint) {
	//copy(目标切片，源切片) 返回值为拷贝成功个数  按照最短为基准
	val := copy(make([]struct{}, b), make([]struct{}, a))
	fmt.Printf("%d\n", val)
}

func main0301() {
	f(90, 314)
	slice := make([]struct{}, 10)
	fmt.Println(slice)

	fmt.Println(len(slice))
	fmt.Println(cap(slice))
	//fmt.Println(unsafe.Sizeof(slice)) 		//24
	//fmt.Println(unsafe.Sizeof(struct {}{}))	//0
}



func main() {
	a := []int{0,1,2,3,4,5,6,7}
	//切片截取  左闭右开
	b := a[:3]

	fmt.Println(len(b))
	fmt.Println(cap(b))
	b = append(b,4)
	fmt.Println(a)
	fmt.Println(b)
}
package main

import (
	"fmt"
)

//func f() {}
//func f(a int) {}
//func f() int { return 0}
//
////在go语言中函数名不允许重名
//func main() {}




//func init() {
//	fmt.Println(1)
//}
//func init() {
//	fmt.Println(2)
//}
//  默认的init函数后缀
//func init()  {
//	var pcs [1]uintptr
//	runtime.Callers(1, pcs[:])
//	fn := runtime.FuncForPC(pcs[0])
//	fmt.Println(fn.Name())
//}
//
//func init()  {
//	var pcs [1]uintptr
//	runtime.Callers(1, pcs[:])
//	fn := runtime.FuncForPC(pcs[0])
//	fmt.Println(fn.Name())
//}




func init() {
	panic("first init")
}

func init() {
	panic("i am the second init")
}

func test() int {
	fmt.Println(4)
	return 4
}


//全局变量
var a int = test()
func main() {
	fmt.Println(3)
}
